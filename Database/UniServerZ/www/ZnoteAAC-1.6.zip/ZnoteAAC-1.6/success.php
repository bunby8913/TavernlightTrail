<?php require_once 'engine/init.php'; include 'layout/overall/header.php'; ?>
<h1>Success!</h1>
Go <script> document.write('<a href="' + document.referrer + '">back</a>'); </script>
<?php include 'layout/overall/footer.php'; ?>