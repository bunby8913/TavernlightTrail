<?php require_once 'engine/init.php'; include 'layout/overall/header.php'; ?>
<h1>Failed!</h1>
<p>Something went wrong. :(</p>
<?php include 'layout/overall/footer.php'; ?>