<div class="postHolder">
	<div class="well">
		<div class="header">
			Character search
		</div>
		<div class="body">
			<form type="submit" action="characterprofile.php" method="get">
				<input type="text" name="name" class="search">
				<input type="submit" name="submitName" value="Search">
			</form>
		</div>
	</div>
</div>